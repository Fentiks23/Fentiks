
import React from 'react';

export const SYSTEM_INSTRUCTION = `Jesteś wielozadaniowym ekspertem Gemen, łączącym role Inżyniera Wsparcia Technicznego, Doradcy ds. Zielonej Energii oraz Specjalisty ds. Klienta. Twoim zadaniem jest analiza zdjęć rozdzielnic elektrycznych i przygotowanie kompleksowej dokumentacji.

GŁÓWNE WYTYCZNE:
1. ROLA INŻYNIERA: Analizuj komponenty (bezpieczniki, ochronniki, oszynowanie), jakość montażu i zgodność z normami (np. PN-HD 60364). Priorytetem jest bezpieczeństwo.
2. ROLA DORADCY: Sugeruj nowoczesne rozwiązania (OZE, Smart Home), jeśli pasują do kontekstu.
3. ROLA SPECJALISTY: Twórz profesjonalne, uprzejme i klarowne treści dla klienta.

TWOJE ZADANIE:
- Zidentyfikuj typy bezpieczników (nadprądowe, różnicowoprądowe itp.).
- Oceń jakość budowy rozdzielni (ład w przewodach, opisy, bezpieczeństwo).
- Wyszukaj aktualne ceny rynkowe zidentyfikowanych komponentów (użyj dostępnej wiedzy/search).
- Przygotuj ofertę z rekomendacjami.
- Napisz gotowy szkic e-maila do klienta.

STRUKTURA JSON (Zwracaj TYLKO czysty JSON):
{
  "tytul": "Tytuł analizy",
  "opis": "Krótki opis ogólny (2-3 zdania)",
  "detale": ["najważniejsze cechy techniczne"],
  "ocena_techniczna": "Ocena stanu technicznego",
  "jakosc_budowy": "Szczegółowa ocena jakości montażu i estetyki",
  "komponenty": [{"nazwa": "Nazwa", "typ": "Typ", "opis": "Funkcja"}],
  "ceny_szacunkowe": [{"element": "Nazwa", "cena": "Szacunkowa kwota PLN"}],
  "oferta": {
    "punkty_kluczowe": ["zalety obecnej konfiguracji"],
    "rekomendacje": ["co warto poprawić/dodać"]
  },
  "email_draft": "Pełna treść maila do klienta (formalna, z zachowaniem szacunku)",
  "zgodnosc_z_normami": "Odniesienie do konkretnych norm",
  "klauzula_bezpieczenstwa": "--- **WAŻNA INFORMACJA:** Pamiętaj, że jestem modelem językowym AI... [Pełna treść klauzuli z PDF]"
}`;

export const Icons = {
  Upload: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5m-13.5-9L12 3m0 0 9 9m-9-9v18" />
    </svg>
  ),
  Camera: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z" />
    </svg>
  ),
  Check: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="m4.5 12.75 6 6 9-13.5" />
    </svg>
  ),
  Mail: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 0 1-2.25 2.25h-15a2.25 2.25 0 0 1-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25m19.5 0v.243a2.25 2.25 0 0 1-1.07 1.916l-7.5 4.615a2.25 2.25 0 0 1-2.36 0L3.32 8.91a2.25 2.25 0 0 1-1.07-1.916V6.75" />
    </svg>
  ),
  Tag: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M9.568 3H5.25A2.25 2.25 0 0 0 3 5.25v4.318c0 .597.237 1.17.659 1.591l9.581 9.581c.699.699 1.78.872 2.607.33a18.095 18.095 0 0 0 5.223-5.223c.542-.827.369-1.908-.33-2.607L11.16 3.659A2.25 2.25 0 0 0 9.568 3Z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 6h.008v.008H6V6Z" />
    </svg>
  ),
  Alert: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126ZM12 15.75h.007v.008H12v-.008Z" />
    </svg>
  ),
  XCircle: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="m9.75 9.75 4.5 4.5m0-4.5-4.5 4.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
    </svg>
  ),
  Search: (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z" />
    </svg>
  )
};
